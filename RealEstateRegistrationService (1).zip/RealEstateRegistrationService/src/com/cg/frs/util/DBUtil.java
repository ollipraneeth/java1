package com.cg.frs.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.cg.frs.exception.FlatRegistrationException;

public class DBUtil {
	private static Connection conn=null;
	private static DBUtil instance = null;
	
	public static Connection getConnection() throws FlatRegistrationException {
		FileInputStream fis = null;
		try {
			
		fis = new FileInputStream("Resources/jdbc.properties");
		Properties pro = new Properties();
		
			pro.load(fis);
			String driver = pro.getProperty("driver");
			String url = pro.getProperty("url_path");
			String user = pro.getProperty("username");
			String password = pro.getProperty("password");
		
		
		
		if(conn==null){
		Class.forName(driver);
				
				conn = DriverManager.getConnection(url,user,password);
				
		}
			   } catch (ClassNotFoundException e) {
				throw new FlatRegistrationException("Driver not found" +e.getMessage());
				
			} catch (SQLException e) {
				throw new FlatRegistrationException("Problem in Esatiblishing Connection" +e.getMessage());
			}catch (IOException e1) {
				System.err.print(e1.getMessage());
		
			}
		
		
		finally{
			if(fis!=null)
				try {
					fis.close();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
		}
		
		return conn;
		
	}
		
		public static DBUtil getInstance() throws FlatRegistrationException {
			synchronized (DBUtil.class) {
				if (instance == null) {
					instance = new DBUtil();
				}
			}
			return instance;
		
	}
}
