package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatOwnersDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;



public class FlatRegistrationServiceImpl implements IFlatRegistrationService{
	IFlatRegistrationDAO dao = new FlatRegistrationDAOImpl();
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatRegistrationException {

		return dao.registerFlat(flat);
	}

	
	@Override
	public List<FlatOwnersDTO> getAllOwnerId() throws FlatRegistrationException {

		return dao.getAllOwnerId();
	}
	
	@Override
	public boolean isValidFlatRegistration(FlatRegistrationDTO flat) throws FlatRegistrationException {
		if(!flat.getOwnerId().matches("^[0-9]$")){
			throw new FlatRegistrationException("Please enter a correct owner id");
		}
		if(!flat.getDepositAmount().matches("^[0-9]{2,30}$")){
			throw new FlatRegistrationException("Please enter a correct deposit amount");
		}
		if(!flat.getFlatArea().matches("^[0-9]{1,10}$")){
			throw new FlatRegistrationException("Please enter a correct flat area");
		}
		if(!flat.getRentAmount().matches("^[0-9]{1,10}$")){
			throw new FlatRegistrationException("Please enter a correct rent amount");
		}
		
		int rentAmt =  Integer.parseInt(flat.getRentAmount());
		int depoAmt =  Integer.parseInt(flat.getDepositAmount());

		if(!(depoAmt>rentAmt)){
			throw new FlatRegistrationException("Deposit amount should be greater than rent amount!!!");
		}
		return true;
	}

}