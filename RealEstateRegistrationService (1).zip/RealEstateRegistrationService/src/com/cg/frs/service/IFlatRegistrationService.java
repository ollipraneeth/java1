package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dto.FlatOwnersDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;

public interface IFlatRegistrationService {
	
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatRegistrationException;
	public List<FlatOwnersDTO> getAllOwnerId() throws FlatRegistrationException;
	public boolean isValidFlatRegistration(FlatRegistrationDTO flat) throws FlatRegistrationException; 
}
