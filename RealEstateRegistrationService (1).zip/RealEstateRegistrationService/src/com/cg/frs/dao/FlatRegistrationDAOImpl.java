package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dto.FlatOwnersDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;
import com.cg.frs.util.DBUtil;



public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {
	Logger logger=Logger.getRootLogger();

	public FlatRegistrationDAOImpl() {

		PropertyConfigurator.configure("Resources/log4j.properties");
	}

	Connection conn = null;

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatRegistrationException {

		try {

			flat.setFlatRegNo(GenerateRegistrationID());


			conn = DBUtil.getConnection();

			PreparedStatement ps = conn.prepareStatement(QuerryMapper.INSERT_REGISTRATION_QUERY);
			ps.setString(1, flat.getFlatRegNo());
			ps.setString(2, flat.getOwnerId());
			ps.setString(3, flat.getFlatType());
			ps.setString(4, flat.getFlatArea());
			ps.setString(5, flat.getRentAmount());
			ps.setString(6, flat.getDepositAmount());
			ps.executeUpdate();


		}catch (SQLException e) {
			throw new FlatRegistrationException("Error in inserting" +e.getMessage());

		} 
		catch (FlatRegistrationException e) {
			throw new FlatRegistrationException("Error in inserting" +e.getMessage());

		} 
		return flat;
	}

	@Override
	public List<FlatOwnersDTO> getAllOwnerId()	throws FlatRegistrationException {

		List<FlatOwnersDTO> flist = new ArrayList<FlatOwnersDTO>(); 
		try {
			conn = DBUtil.getConnection();


			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(QuerryMapper.RETRIVE_ALL_OWNERID_QUERY);
			while(rst.next()){
				FlatOwnersDTO f = new FlatOwnersDTO();
				f.setOwnerId(rst.getString("owner_id"));

				flist.add(f);
			} 
		}catch (SQLException e1) {
			logger.error("Error In fetching Id's" +e1.getMessage());
			throw new FlatRegistrationException("Ids Not Found");
		}

		logger.info("Id List Generated Succesfully");
		return flist;
	}
	private String GenerateRegistrationID() throws FlatRegistrationException{
		String rid = null;
		conn = DBUtil.getConnection();

		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(QuerryMapper.REGISTRATIONID_SEQUENCE_QUERY);
			rst.next();
			rid = rst.getString(1);
		} catch (SQLException e) {
			throw new FlatRegistrationException("Problem in Generating RegistrationId" +e.getMessage());
		}
		logger.info("RegistrationId Succesfully Generated");
		return rid;
	}
}
